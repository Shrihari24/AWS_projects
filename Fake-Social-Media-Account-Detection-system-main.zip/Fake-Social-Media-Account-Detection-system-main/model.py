import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import joblib
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer

def train():
    insta_data = pd.read_csv('dataset.csv')  # Ensure your dataset has the correct format
    
    # Drop rows with missing values in the target column 'fake'
    insta_data = insta_data.dropna(subset=['fake'])
    
    insta_X = insta_data.drop('fake', axis=1)
    insta_y = insta_data['fake']

    # Define the pipeline
    insta_model = Pipeline(steps=[
        ('preprocessor', ColumnTransformer(transformers=[
            ('num', StandardScaler(), ['profile pic', 'nums/length username', 'fullname words', 
                'nums/length fullname', 'name==username', 'description length', 
                'external URL', '#posts', '#followers', '#follows']),
            ('cat', OneHotEncoder(), ['private'])
        ])),
        ('classifier', RandomForestClassifier())
    ])

    # Fit the model
    insta_model.fit(insta_X, insta_y)
    
    #  Save the trained model
    joblib.dump(insta_model, 'insta_model.joblib')
    print("Model training complete and saved as 'insta_model.joblib'.")

if __name__ == '__main__':
    train()
