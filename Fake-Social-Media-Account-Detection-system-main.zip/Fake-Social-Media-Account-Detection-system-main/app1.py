import pandas as pd
import joblib
import json
from flask import Flask, render_template, request, redirect, url_for, jsonify
import requests
import numpy as np

app = Flask(__name__)
model = joblib.load('insta_model.joblib')  # Load your trained model

# New Instagram API endpoint
API_URL = "https://instagram120.p.rapidapi.com/api/instagram/userInfo"
HEADERS = {
    "x-rapidapi-key": "8e9f767f41msh823156599ef2789p193efbjsn96f0d314b334",
    "x-rapidapi-host": "instagram120.p.rapidapi.com",
    "Content-Type": "application/json"
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    username = request.form['username'].strip()
    if not username:
        return render_template('result.html', error="Username is required.")

    # Fetch profile data
    try:
        resp = requests.post(API_URL, json={"username": username}, headers=HEADERS)
        resp.raise_for_status()
        data = resp.json()
        # the API wraps the user under result[0].user
        profile = data['result'][0]['user']
    except Exception as e:
        print("API error:", e)
        return render_template('result.html', error="Could not fetch profile data.")

    # Build feature dict
    new_data = {
        'profile pic': 1 if profile.get('hd_profile_pic_url_info', {}).get('url') else 0,
        'nums/length username': sum(c.isdigit() for c in username) / len(username),
        'fullname words': len(profile.get('full_name', "").split()),
        'nums/length fullname': (
            sum(c.isdigit() for c in profile.get('full_name', "")) /
            len(profile.get('full_name', ""))
        ) if profile.get('full_name') else 0,
        'name==username': 1 if username.lower() == profile.get('full_name', "").replace(" ", "").lower() else 0,
        'description length': len(profile.get('biography', "")),
        'external URL': 1 if profile.get('external_url') else 0,
        '#posts': profile.get('media_count', 0),
        '#followers': profile.get('follower_count', 0),
        '#follows': profile.get('following_count', 0),
        'private': 1 if profile.get('is_private') else 0
    }

    # Predict
    X = pd.DataFrame([new_data])
    try:
        pred = model.predict(X)[0]
        final_result = "Fake" if pred == 1 else "Real"
    except Exception as e:
        print("Prediction error:", e)
        return render_template('result.html', error="Model prediction failed.")

    # Save only the features and result (no URLs)
    with open('result_data.json', 'w') as f:
        json.dump({'result': final_result, 'response': new_data}, f)

    return redirect(url_for('result'))

@app.route('/result')
def result():
    try:
        with open('result_data.json') as f:
            data = json.load(f)
    except Exception as e:
        print("Result load error:", e)
        return render_template('result.html', error="No result to display.")
    return render_template('result.html', result=data['result'], response=data['response'])

if __name__ == '__main__':
    app.secret_key = 'super secret key'
    app.run(debug=True)
